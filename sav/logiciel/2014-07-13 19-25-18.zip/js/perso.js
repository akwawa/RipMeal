function test() {
	alert('ok');
}