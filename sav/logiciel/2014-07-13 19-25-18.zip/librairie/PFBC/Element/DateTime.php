<?php
namespace PFBC\Element;

class DateTime extends Textbox {
	protected $_attributes = array("type" => "datetime");
}
