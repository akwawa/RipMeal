<?php
namespace PFBC\Element;

class Phone extends Textbox {
	protected $_attributes = array("type" => "tel");
}
