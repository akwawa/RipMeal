-- MySQL dump 10.13  Distrib 5.5.25a, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: ripmeal
-- ------------------------------------------------------
-- Server version	5.5.25a

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `v3__menu`
--

DROP TABLE IF EXISTS `v3__menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v3__menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idEntree` int(11) NOT NULL,
  `idViande` int(11) NOT NULL,
  `idLegume` int(11) NOT NULL,
  `idFromage` int(11) NOT NULL,
  `idDessert` int(11) NOT NULL,
  `supplement` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idEntree` (`idEntree`,`idViande`,`idLegume`,`idFromage`,`idDessert`),
  KEY `idViande` (`idViande`),
  KEY `idLegume` (`idLegume`),
  KEY `idDessert` (`idDessert`),
  KEY `idFromage` (`idFromage`),
  CONSTRAINT `v3__menu_ibfk_1` FOREIGN KEY (`idEntree`) REFERENCES `v3__menu_entree` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_ibfk_2` FOREIGN KEY (`idViande`) REFERENCES `v3__menu_viande` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_ibfk_3` FOREIGN KEY (`idLegume`) REFERENCES `v3__menu_legume` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_ibfk_4` FOREIGN KEY (`idFromage`) REFERENCES `v3__menu_fromage` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_ibfk_5` FOREIGN KEY (`idDessert`) REFERENCES `v3__menu_dessert` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v3__menu`
--

LOCK TABLES `v3__menu` WRITE;
/*!40000 ALTER TABLE `v3__menu` DISABLE KEYS */;
INSERT INTO `v3__menu` VALUES (61,24,26,25,19,19,''),(62,25,27,26,20,20,''),(63,26,28,27,21,21,''),(64,27,29,28,22,22,''),(65,28,30,29,23,23,''),(66,29,31,30,24,24,''),(67,30,32,31,25,25,''),(68,31,33,32,26,26,''),(69,32,34,33,27,27,''),(70,33,35,30,28,28,''),(71,34,36,34,29,29,''),(72,35,37,30,30,30,''),(73,36,38,35,31,31,''),(74,37,39,36,32,32,''),(75,38,40,37,33,33,''),(76,39,41,38,34,34,''),(77,40,42,39,21,21,''),(78,27,43,40,22,22,''),(79,41,44,41,23,23,''),(80,29,45,42,24,24,''),(81,42,46,43,25,25,''),(82,31,47,44,26,26,''),(83,43,42,45,27,27,''),(84,33,43,39,28,28,''),(85,40,44,40,29,29,''),(86,35,45,41,30,30,''),(87,44,46,43,31,31,''),(88,37,47,42,32,32,''),(89,45,48,46,35,23,''),(90,46,49,47,36,35,''),(91,43,46,45,35,23,''),(92,46,50,48,36,35,''),(93,49,48,46,35,23,'');
/*!40000 ALTER TABLE `v3__menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-08 22:37:43
