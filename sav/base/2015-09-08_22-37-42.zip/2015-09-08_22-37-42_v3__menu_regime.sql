-- MySQL dump 10.13  Distrib 5.5.25a, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: ripmeal
-- ------------------------------------------------------
-- Server version	5.5.25a

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `v3__menu_regime`
--

DROP TABLE IF EXISTS `v3__menu_regime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v3__menu_regime` (
  `idMenu` int(11) NOT NULL,
  `idRegime` int(11) NOT NULL,
  `idCalendrier` int(11) NOT NULL,
  PRIMARY KEY (`idMenu`,`idRegime`,`idCalendrier`),
  KEY `idRegime` (`idRegime`),
  KEY `idCalendrier` (`idCalendrier`),
  CONSTRAINT `v3__menu_regime_ibfk_1` FOREIGN KEY (`idMenu`) REFERENCES `v3__menu` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_regime_ibfk_2` FOREIGN KEY (`idRegime`) REFERENCES `v3__regime` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_regime_ibfk_3` FOREIGN KEY (`idCalendrier`) REFERENCES `v3__calendrier` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v3__menu_regime`
--

LOCK TABLES `v3__menu_regime` WRITE;
/*!40000 ALTER TABLE `v3__menu_regime` DISABLE KEYS */;
INSERT INTO `v3__menu_regime` VALUES (61,1,57),(61,1,85),(61,1,99),(61,1,113),(61,1,127),(62,1,58),(62,1,86),(62,1,100),(62,1,114),(62,1,128),(63,1,59),(63,1,73),(63,1,87),(63,1,101),(63,1,115),(63,1,129),(63,1,143),(64,1,60),(64,1,74),(64,1,88),(64,1,102),(64,1,116),(64,1,130),(64,1,144),(65,1,61),(65,1,75),(65,1,89),(65,1,103),(65,1,117),(65,1,131),(65,1,145),(66,1,62),(66,1,76),(66,1,90),(66,1,104),(66,1,118),(66,1,132),(66,1,146),(67,1,63),(67,1,77),(67,1,91),(67,1,105),(67,1,119),(67,1,133),(67,1,147),(68,1,64),(68,1,78),(68,1,92),(68,1,106),(68,1,120),(68,1,134),(68,1,148),(69,1,65),(69,1,79),(69,1,93),(69,1,107),(69,1,121),(69,1,135),(69,1,149),(70,1,66),(70,1,80),(70,1,94),(70,1,108),(70,1,122),(70,1,136),(70,1,150),(71,1,67),(71,1,81),(71,1,95),(71,1,109),(71,1,123),(71,1,137),(71,1,151),(72,1,68),(72,1,82),(72,1,96),(72,1,110),(72,1,124),(72,1,138),(72,1,152),(73,1,69),(73,1,83),(73,1,97),(73,1,111),(73,1,125),(73,1,139),(73,1,153),(74,1,70),(74,1,84),(74,1,98),(74,1,112),(74,1,126),(74,1,140),(74,1,154),(90,1,72),(90,1,114),(90,1,142),(93,1,71),(93,1,113),(93,1,141),(75,2,57),(75,2,85),(75,2,99),(75,2,113),(75,2,127),(76,2,58),(76,2,86),(76,2,100),(76,2,114),(76,2,128),(77,2,59),(77,2,73),(77,2,87),(77,2,101),(77,2,115),(77,2,129),(77,2,143),(78,2,60),(78,2,74),(78,2,88),(78,2,102),(78,2,116),(78,2,130),(78,2,144),(79,2,61),(79,2,75),(79,2,89),(79,2,103),(79,2,117),(79,2,131),(79,2,145),(80,2,62),(80,2,76),(80,2,90),(80,2,104),(80,2,118),(80,2,132),(80,2,146),(81,2,63),(81,2,77),(81,2,91),(81,2,105),(81,2,119),(81,2,133),(81,2,147),(82,2,64),(82,2,78),(82,2,92),(82,2,106),(82,2,120),(82,2,134),(82,2,148),(83,2,65),(83,2,79),(83,2,93),(83,2,107),(83,2,121),(83,2,135),(83,2,149),(84,2,66),(84,2,80),(84,2,94),(84,2,108),(84,2,122),(84,2,136),(84,2,150),(85,2,67),(85,2,81),(85,2,95),(85,2,109),(85,2,123),(85,2,137),(85,2,151),(86,2,68),(86,2,82),(86,2,96),(86,2,110),(86,2,124),(86,2,138),(86,2,152),(87,2,69),(87,2,83),(87,2,97),(87,2,111),(87,2,125),(87,2,139),(87,2,153),(88,2,70),(88,2,84),(88,2,98),(88,2,112),(88,2,126),(88,2,140),(88,2,154),(91,2,71),(91,2,113),(91,2,141),(92,2,72),(92,2,114),(92,2,142);
/*!40000 ALTER TABLE `v3__menu_regime` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-08 22:37:43
