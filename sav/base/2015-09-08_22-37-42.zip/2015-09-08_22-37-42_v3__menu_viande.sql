-- MySQL dump 10.13  Distrib 5.5.25a, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: ripmeal
-- ------------------------------------------------------
-- Server version	5.5.25a

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `v3__menu_viande`
--

DROP TABLE IF EXISTS `v3__menu_viande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v3__menu_viande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v3__menu_viande`
--

LOCK TABLES `v3__menu_viande` WRITE;
/*!40000 ALTER TABLE `v3__menu_viande` DISABLE KEYS */;
INSERT INTO `v3__menu_viande` VALUES (26,'viande midi','viande midi'),(27,'viande soir','viande soir'),(28,'Sauté de bœuf sauce aux champignons noirs','Sauté de bœuf sauce aux champignons noirs'),(29,'Quiche Lorraine','Quiche Lorraine'),(30,'Rôti de porc sauce charcutière','Rôti de porc sauce charcutière'),(31,'Spaghetti bolognaise','Spaghetti bolognaise'),(32,'Cassoulet','Cassoulet'),(33,'Emincé de dinde curry','Emincé de dinde curry'),(34,'Filet de Hoki meunière sauce mayonnaise','Filet de Hoki meunière sauce mayonnaise'),(35,'Tartiflette','Tartiflette'),(36,'Poulet rôti','Poulet rôti'),(37,'Moussaka','Moussaka'),(38,'Pot au feu','Pot au feu'),(39,'Omelette','Omelette'),(40,'viande rem midi','viande rem midi'),(41,'viande rem soir','viande rem soir'),(42,'Cuisse de poulet','Cuisse de poulet'),(43,'Normandin','Normandin'),(44,'Boule bœuf','Boule bœuf'),(45,'Fricadelle','Fricadelle'),(46,'Poisson pané','Poisson pané'),(47,'Jambon','Jambon'),(48,'Cordon bleu','Cordon bleu'),(49,'Bouchée à la reine','Bouchée à la reine'),(50,'Tomates farcies','Tomates farcies'),(51,'viande midi','viande midi'),(52,'viande midi','viande midi');
/*!40000 ALTER TABLE `v3__menu_viande` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-08 22:37:44
