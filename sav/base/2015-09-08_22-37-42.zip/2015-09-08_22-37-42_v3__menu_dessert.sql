-- MySQL dump 10.13  Distrib 5.5.25a, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: ripmeal
-- ------------------------------------------------------
-- Server version	5.5.25a

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `v3__menu_dessert`
--

DROP TABLE IF EXISTS `v3__menu_dessert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v3__menu_dessert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v3__menu_dessert`
--

LOCK TABLES `v3__menu_dessert` WRITE;
/*!40000 ALTER TABLE `v3__menu_dessert` DISABLE KEYS */;
INSERT INTO `v3__menu_dessert` VALUES (19,'dessert midi','dessert midi'),(20,'dessert soir','dessert soir'),(21,'Compote de pommes','Compote de pommes'),(22,'Pêches au sirop','Pêches au sirop'),(23,'Fruit','Fruit'),(24,'Crème dessert caramel','Crème dessert caramel'),(25,'Flan pâtissier','Flan pâtissier'),(26,'Cocktail de fruits','Cocktail de fruits'),(27,'Salade fruits frais','Salade fruits frais'),(28,'Mousse au citron','Mousse au citron'),(29,'Crème dessert au café','Crème dessert au café'),(30,'Abricots cuits au sirop','Abricots cuits au sirop'),(31,'Bavarois','Bavarois'),(32,'Fruit cru','Fruit cru'),(33,'dessert remp midi','dessert remp midi'),(34,'dessert remp soir','dessert remp soir'),(35,'Mousse au chocolat','Mousse au chocolat'),(36,'dessert midi','dessert midi'),(37,'dessert midi','dessert midi');
/*!40000 ALTER TABLE `v3__menu_dessert` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-08 22:37:43
