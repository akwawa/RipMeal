-- MySQL dump 10.13  Distrib 5.5.25a, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: ripmeal
-- ------------------------------------------------------
-- Server version	5.5.25a

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `v3__menu_regime`
--

DROP TABLE IF EXISTS `v3__menu_regime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v3__menu_regime` (
  `idMenu` int(11) NOT NULL,
  `idRegime` int(11) NOT NULL,
  `idCalendrier` int(11) NOT NULL,
  PRIMARY KEY (`idMenu`,`idRegime`,`idCalendrier`),
  KEY `idRegime` (`idRegime`),
  KEY `idCalendrier` (`idCalendrier`),
  CONSTRAINT `v3__menu_regime_ibfk_1` FOREIGN KEY (`idMenu`) REFERENCES `v3__menu` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_regime_ibfk_2` FOREIGN KEY (`idRegime`) REFERENCES `v3__regime` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `v3__menu_regime_ibfk_3` FOREIGN KEY (`idCalendrier`) REFERENCES `v3__calendrier` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v3__menu_regime`
--

LOCK TABLES `v3__menu_regime` WRITE;
/*!40000 ALTER TABLE `v3__menu_regime` DISABLE KEYS */;
INSERT INTO `v3__menu_regime` VALUES (61,1,57),(61,1,85),(62,1,58),(62,1,86),(63,1,59),(63,1,73),(63,1,87),(64,1,60),(64,1,74),(64,1,88),(65,1,61),(65,1,75),(65,1,89),(66,1,62),(66,1,76),(66,1,90),(67,1,63),(67,1,77),(67,1,91),(68,1,64),(68,1,78),(68,1,92),(69,1,65),(69,1,79),(69,1,93),(70,1,66),(70,1,80),(70,1,94),(71,1,67),(71,1,81),(71,1,95),(72,1,68),(72,1,82),(72,1,96),(73,1,69),(73,1,83),(73,1,97),(74,1,70),(74,1,84),(74,1,98),(90,1,72),(93,1,71),(75,2,57),(75,2,85),(76,2,58),(76,2,86),(77,2,59),(77,2,73),(77,2,87),(78,2,60),(78,2,74),(78,2,88),(79,2,61),(79,2,75),(79,2,89),(80,2,62),(80,2,76),(80,2,90),(81,2,63),(81,2,77),(81,2,91),(82,2,64),(82,2,78),(82,2,92),(83,2,65),(83,2,79),(83,2,93),(84,2,66),(84,2,80),(84,2,94),(85,2,67),(85,2,81),(85,2,95),(86,2,68),(86,2,82),(86,2,96),(87,2,69),(87,2,83),(87,2,97),(88,2,70),(88,2,84),(88,2,98),(91,2,71),(92,2,72);
/*!40000 ALTER TABLE `v3__menu_regime` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-13 19:25:18
